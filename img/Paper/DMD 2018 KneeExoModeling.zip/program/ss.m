texp=theta;
dexp2=theta;
t=0:0.01:2*pi;
x=a*cos(t);
y=b*sin(t);
xy=zeros([2,length(texp)]);
figure;
hold on;
axis equal;
ttt=-80:1:20;
yyy=0*ttt;
plot(ttt,yy,'k','LineWidth',1);
for k=1:length(texp)
    tt=texp(k)/180*pi;
    xy(:,k)=ellipsexy(a,b,tt)';
    new=[cos(tt) -sin(tt); sin(tt) cos(tt)]*[x;y];
    new=xy(:,k)+new;
    new2=new;
    slidevec=zeros([6,1]);
    for j=1:6
        slidevec(j)=((texp(k)-mean(kk))/std(kk))^(6-j);
    end
    dslide=pslide*slidevec;
    ddd(k)=xy(1,k)+dslide;
    new2(1,:)=new(1,:)+dslide;
    [~,flg]=min(new2(2,:));
    dexp2(k)=new2(1,flg);
    plot(new(1,:),new(2,:),'--b','LineWidth',1);
    hold on;
    plot(new2(1,:),new2(2,:),'r','LineWidth',1);
end
