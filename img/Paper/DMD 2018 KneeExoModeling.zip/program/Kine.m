a=33.6;b=23;
theta = [-5,5,10,20,30,45,90,110,120];
thetanom=(theta-mean(theta))/std(theta);
dexp = 31-[31 30 25 24 23 22 15 10 8];
pall = polyfit(thetanom,dexp,5);
d0 = arcl(a,b,-5/180*pi);
droll=zeros([1,20]);
for k=1:20
    droll(k)=arcl(a,b,(-5+6.25*(k-1))/180*pi)-d0;
end
k=1:20;
kk=-5+6.25*(k-1);
knom=(kk-mean(kk))/std(kk);
proll = polyfit(knom,droll,5);
dslide=zeros([1,20]);
for k=1:20
    ang=kk(k);
    expvec=zeros([6,1]);
    rollvec=zeros([6,1]);
    for j=1:6
        expvec(j)=((ang-mean(theta))/std(theta))^(6-j);
        rollvec(j)=((ang-mean(kk))/std(kk))^(6-j);
    end
    dslide(k)=proll*rollvec-pall*expvec;
end
pslide = polyfit(knom,dslide,5);
slidevec=zeros([6,1]);
for j=1:6
    slidevec(j)=((0-mean(kk))/std(kk))^(6-j);
end
x0 = pslide * slidevec;
xtb = 3;
ytb = 4;
load('hipflexangle.txt');
load('kneeflexangle.txt');
load('pelvistiltangle.txt');
load('pelvist.txt');
mfemur = 8.98403823;
mtibia = 3.5810009;
lfemur = 0.195031*2-b/1000;
ltibia = 0.184557*2;
Jfemur = 0.13638229;
Jtibia = 0.04935648;
lexotibia = 0.2;
mexo=0.55;
Jexo=0.0057;
load('ankleontibiafxfyfz.txt');
load('ankleontibiamoment.txt');
load('anklemoment.txt');
ankleontibiafx=ankleontibiafxfyfz(:,2:3);
ankleontibiafy=ankleontibiafxfyfz(:,2:2:4);
ankleontibiafz=ankleontibiafxfyfz(:,2:3:5);
ankleontibiamx=ankleontibiamoment(:,2:3);
ankleontibiamy=ankleontibiamoment(:,2:2:4);
ankleontibiamz=ankleontibiamoment(:,2:3:5);
anklemoment=anklemoment(:,2:3);

